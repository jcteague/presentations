﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.Command;
using Machine.Specifications;
using Moq;
using It = Machine.Specifications.It;

namespace UnitTests
{
    public class CreateOrderSpecs

    {
        private static Order order;
        private static CreateOrderClassic sut;
        static bool result;
        private Establish context = () =>
                                        {
                                            var product1 = new Product() {Id = 1, Name = "prod1"};
                                            var product2 = new Product() {Id = 2, Name = "prod1"};
                                            var inventory1 = new InventoryProduct() {ProductId = 1, QuantityInStock = 5};
                                            var inventory2 = new InventoryProduct() {ProductId = 1, QuantityInStock = 1};
                                            var inventory_query_result = new[] {inventory1, inventory2};
                                            order = new Order()
                                                        {
                                                            BillingAddress =
                                                                new Address()
                                                                    {
                                                                        City = "city",
                                                                        State = "st",
                                                                        Street = "street",
                                                                        Zip = "zip"
                                                                    },
                                                            MailingAddress =
                                                                new Address()
                                                                    {
                                                                        City = "city",
                                                                        State = "st",
                                                                        Street = "street",
                                                                        Zip = "zip"
                                                                    },
                                                            CreditCardNumber = "4111111111111111",
                                                            OrderItems = new[]
                                                                        {
                                                                            new LineItem(){Quantity = 1, ItemPurchased = product1},
                                                                            new LineItem(){Quantity = 2, ItemPurchased = product2},
                                                                        }
                                                        };
                                            var repository = new Mock<IProductInventoryRepository>();
                                            repository.Setup(
                                                x => x.GetQuantityForItemsInOrder(Moq.It.IsAny<IEnumerable<LineItem>>()))
                                                .Returns(inventory_query_result);
                                            sut = new CreateOrderClassic(repository.Object);
                                        };

        private Because of = () => result = sut.OrderIsValid(order);

        It should_return_false_when_product_inventory_is_lower_than_order_quantity = () => result.ShouldBeFalse();

    }
}
