using Core.Command;
using Core.Visitor;
using Machine.Specifications;

namespace UnitTests
{
    public class VistorSpecs
    {
        private static Order order;
        private static OrderTotalDiscountVisitor totalVisitor;

        private Establish context = () =>
                                        {
                                            totalVisitor = new OrderTotalDiscountVisitor();
                                            var product1 = new Product() {Id = 1, Name = "prod1", Price = 200};
                                            var product2 = new Product() {Id = 2, Name = "prod1", Price = 50};
                                            var inventory1 = new InventoryProduct() {ProductId = 1, QuantityInStock = 5};
                                            var inventory2 = new InventoryProduct() {ProductId = 1, QuantityInStock = 1};
                                            var inventory_query_result = new[] {inventory1, inventory2};
                                            order = new Order()
                                                        {

                                                            OrderItems = new[]
                                                                             {
                                                                                 new LineItem()
                                                                                     {
                                                                                         Quantity = 5,
                                                                                         ItemPurchased = product1
                                                                                     },
                                                                                 new LineItem()
                                                                                     {
                                                                                         Quantity = 2,
                                                                                         ItemPurchased = product2
                                                                                     },
                                                                             }
                                                        };
                                        };

        private Because of = () => totalVisitor.Visit(order);
        private It should_apply_the_discount = () => order.Discount.ShouldEqual(.15);
    }
}