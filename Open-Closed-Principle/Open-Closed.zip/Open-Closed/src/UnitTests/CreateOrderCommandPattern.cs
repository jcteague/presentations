using System;
using System.Collections.Generic;
using System.Linq;
using Core.Command;

namespace UnitTests
{
    public class CreateOrderCommandPattern
    {
        private readonly IEnumerable<ICommand<Order>> _verifications;

        public CreateOrderCommandPattern(IEnumerable<ICommand<Order>> verifications)
        {
          _verifications = verifications;
        }

        public bool OrderIsValid(Order order)
        {
            foreach (var command in _verifications)
            {
                var result = command.Execute(order);
                if (result == false) return false;
            }
            return true;

        }
    }

    public interface ICommand<T>
    {
        bool Execute(T item);
    }

    public class AddressVerifcation 
    {
        public bool VerifyAddress(Address item)
        {
            return item.Street != null && item.City != null && item.State != null && item.Zip != null;
        }
    }
    public class OrderMailingAddressVerifcation : ICommand<Order>
    {
        public bool Execute(Order item)
        {
            return new AddressVerifcation().VerifyAddress(item.MailingAddress);
        }
    }
    public class OrderBillingAddressVerification : ICommand<Order>
    {
        public bool Execute(Order item)
        {
            return new AddressVerifcation().VerifyAddress(item.MailingAddress);
        }
    }
    public class OrderCreditCardVerifcation : ICommand<Order>
    {
        public bool Execute(Order item)
        {
            return item.CreditCardNumber.Length == 16;
        }
    }

    public class InventoryQuantityVerfication : ICommand<Order>
    {
        private readonly IProductInventoryRepository _repository;

        public InventoryQuantityVerfication(IProductInventoryRepository repository)
        {
            _repository = repository;
        }
        public bool Execute(Order item)
        {
            return _repository.GetQuantityForItemsInOrder(item.OrderItems).Any(x => x.QuantityInStock < OrderItemQuantityForInventoryProduct(x, item));
        }
        
        private int OrderItemQuantityForInventoryProduct(InventoryProduct x, Order order)
        {
            return order.OrderItems.Single(i => i.ItemPurchased.Id == x.ProductId).Quantity;
        }

    }
}
