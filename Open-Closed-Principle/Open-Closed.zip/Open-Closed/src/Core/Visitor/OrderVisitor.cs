using System;
using Core.Command;
using System.Linq;

namespace Core.Visitor
{
    public class QuantityDiscountVisitor : IVisitor<Order>
    {
        public void Visit(Order item)
        {
            var quantityTotal = item.OrderItems.Sum(x => x.Quantity);
            if(quantityTotal > 5)
            {
                item.Discount += .1;
            }
        }
    }

    public class OrderTotalDiscountVisitor : IVisitor<Order>
    {
        public void Visit(Order item)
        {
            var orderTotal = item.OrderItems.Sum(x => x.Quantity*x.ItemPurchased.Price);
            if(orderTotal > 100)
            {
                item.Discount += .15;
            }
        }
    }

    public interface IVisitor<T>
    {
        void Visit(T item);
    }
}