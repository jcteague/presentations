using System.Linq;

namespace Core.Command
{
    public class CreateOrderClassic
    {
        private readonly IProductInventoryRepository _inventoryRepository;

        public CreateOrderClassic(IProductInventoryRepository inventoryRepository)
        {
            _inventoryRepository = inventoryRepository;
        }

        public bool OrderIsValid(Order order)
        {
            if (order.BillingAddress.Street == null || order.BillingAddress.City == null || order.BillingAddress.State == null && order.BillingAddress.Zip == null)
                return false;
            if (order.MailingAddress.Street == null || order.MailingAddress.City == null || order.MailingAddress.State == null && order.MailingAddress.Zip == null)
                return false;
            if (order.CreditCardNumber.Length != 16) return false;
            bool products_are_in_stock =  _inventoryRepository.GetQuantityForItemsInOrder(order.OrderItems).Any(x=>x.QuantityInStock < OrderItemQuantityForInventoryProduct(x, order));
            return products_are_in_stock;

                
        }

        private int OrderItemQuantityForInventoryProduct(InventoryProduct x, Order order)
        {
            return order.OrderItems.Single(i=>i.ItemPurchased.Id == x.ProductId).Quantity;
        }
    }
}