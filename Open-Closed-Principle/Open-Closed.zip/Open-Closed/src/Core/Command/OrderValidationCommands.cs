using System;
using System.Collections.Generic;
using System.Linq;

namespace Core.Command
{
    public class OrderValidation
    {
        private readonly IEnumerable<ICommand<Order>> _validations;

        public OrderValidation(IEnumerable<ICommand<Order>> validations)
        {
            _validations = validations;
        }
        public bool Validate(Order order)
        {
            foreach (var validation in _validations)
            {
                var result = validation.Execute(order);
                if (!result) return false;
            }
            return true;
        }
    }


    public interface ICommand<T>
    {
        bool Execute(T item);
    }
    public class AddressValidation
    {
        public static bool Validate(Address address)
        {
            return address.Street != null && address.State != null;
        }
    }

    public class MailingAddressValidatationCommand : ICommand<Order>{
        public bool Execute(Order item)
        {
            return AddressValidation.Validate(item.MailingAddress);
        }
    }
    public class BillingAddressValidatationCommand : ICommand<Order>{
        public bool Execute(Order item)
        {
            return AddressValidation.Validate(item.BillingAddress);
        }
    }
    public class CreditCartValidatationCommand : ICommand<Order>{
        public bool Execute(Order item)
        {
            return item.CreditCardNumber.Length == 16;
        }
    }
    public class ProductsAreInStockValidatationCommand : ICommand<Order>{
        private readonly IProductInventoryRepository _repository;

        ProductsAreInStockValidatationCommand(IProductInventoryRepository repository)
        {
            _repository = repository;
        }
        public bool Execute(Order item)
        {
           return _repository.GetQuantityForItemsInOrder(item.OrderItems)
                .Any(x => x.QuantityInStock < OrderItemQuantityForInventoryProduct(x, item));
        }

        private int OrderItemQuantityForInventoryProduct(InventoryProduct x, Order order)
        {
            return order.OrderItems.Single(i => i.ItemPurchased.Id == x.ProductId).Quantity;
        }
    }

    
}