﻿using System.Collections.Generic;

namespace Core.Command
{
    public interface IProductInventoryRepository
    {
        IEnumerable<InventoryProduct> GetQuantityForItemsInOrder(IEnumerable<LineItem> orderItems);
    }

    public class InventoryProduct
    {
        public int ProductId { get; set; }
        public int QuantityInStock { get; set; }
    }
}