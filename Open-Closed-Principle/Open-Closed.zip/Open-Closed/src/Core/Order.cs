﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;

namespace Core.Command
{
    public class Order
    {
        public Address BillingAddress { get; set; }
        public Address MailingAddress{get;set;}
        public IEnumerable<LineItem> OrderItems{get;set;}

        public string CreditCardNumber { get; set; }

        public double Discount  { get; set; }
    }

    public class LineItem
    {
        public int Quantity { get; set; }
        public Product ItemPurchased { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }

    public class Address
    {
        public string Street { get; set; }
        public string City { get; set; }
        public string State{ get; set;}
        public string Zip { get; set; }

    }
}